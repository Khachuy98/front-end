<template>
    <div class="container">
      <b-card class="cardinfo"
        overlay
        img-src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT-yPZcf8IYnC-A2jb-bRjUAKnCyYcSDe_vtV2vJcHnNYXvdGHmVsBeWD7wQoyKtA7_g4w&usqp=CAU"
        img-alt="Card Image"
        text-variant="white"
        title="Boot Dr.Martent"
        sub-title="Spring 2021"
      >
      </b-card>
      <b-card class="cardinfo"
        overlay
        img-src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRccgrFWh55cacGwcSndwwnKoNLSBGsRbbqh0bbWYDNglWnXdlaMldoF0WUh9yOZuQkk5c&usqp=CAU"
        img-alt="Card Image"
        text-variant="white"
        title="Oxford"
        sub-title="New trend"
      >
      </b-card>
            <b-card class="cardinfo"
        overlay
        img-src="https://giaygiare.vn/upload/sanpham/large/converse-1970s-x-g-dragon-nam-nu-1-1.jpg"
        img-alt="Card Image"
        text-variant="white"
        title="Sneaker"
        sub-title="Summer 2021"
      >
      </b-card>
    </div>
</template>

<script>
export default {};
</script>

<style scoped>
    .container{
        max-width: 1200px;
     
    }
    .cardinfo{
        width: 300px;
        height: 300px;
        display:inline-block;
        padding: 15px 15px;
        margin: 10px 45px;
    }
</style>