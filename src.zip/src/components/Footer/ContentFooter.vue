<template>
  <footer class="footer">
    <div class="container-fluid">
      <div class="copyright text-center">
        &copy; Coded with
        <i class="fa fa-heart heart"></i> by
        <a href="#" target="_blank">Hlee</a>.
        Designed by <a href="#" target="_blank">Shoes Store</a>.
      </div>
    </div>
  </footer>
</template>
<script>
  export default {}

</script>
<style>

</style>
